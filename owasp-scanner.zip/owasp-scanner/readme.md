# OWASP Top 10 Passive Scanner

This is a full-stack web application designed to perform a passive, external scan of a user-provided URL for indicators of the OWASP Top 10 vulnerabilities.

## Features

-   **Frontend:** Clean, responsive UI built with React and Tailwind CSS.
-   **Backend:** Secure Flask API for performing the scans.
-   **Passive Analysis:** All checks are non-intrusive and use only publicly available information.
-   **Dockerized:** One-command deployment using Docker and Docker Compose.
-   **Tested:** Includes unit and integration tests for the backend logic.

## Prerequisites

-   Docker
-   Docker Compose

## How to Run

1.  **Clone the repository or save the files** into the structure described above.

2.  **Navigate to the project root directory** (`owasp-scanner/`).

3.  **Build and run the containers:**
    ```bash
    docker-compose up --build
    ```

4.  **Access the application:**
    -   **Frontend:** Open your web browser and go to `http://localhost:8080`
    -   **Backend API:** The API is available at `http://localhost:5000`

## How to Run Tests

To run the backend unit and integration tests, execute the following command while the containers are running:

```bash
docker-compose exec backend pytest