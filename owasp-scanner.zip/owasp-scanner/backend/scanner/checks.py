from bs4 import BeautifulSoup
import requests

# Note: Many OWASP Top 10 require active, authenticated testing. 
# These checks are passive interpretations looking for common misconfiguration indicators.

def check_security_headers(headers: dict):
    """A05:2021 - Security Misconfiguration"""
    results = []
    # Check for Content-Security-Policy (also helps with A03:Injection)
    if 'Content-Security-Policy' not in headers:
        results.append({"name": "Content-Security-Policy (CSP)", "status": "Failed", "details": "CSP header not found. This is crucial for preventing XSS and other injection attacks."})
    else:
        results.append({"name": "Content-Security-Policy (CSP)", "status": "Passed", "details": "CSP header is present."})

    # Check for X-Frame-Options (Clickjacking protection)
    if 'X-Frame-Options' not in headers and 'frame-ancestors' not in headers.get('Content-Security-Policy', ''):
        results.append({"name": "X-Frame-Options", "status": "Failed", "details": "Header not found. Site may be vulnerable to clickjacking."})
    else:
        results.append({"name": "X-Frame-Options", "status": "Passed", "details": "Clickjacking protection is likely in place."})

    # Check for Strict-Transport-Security (HSTS)
    if 'Strict-Transport-Security' not in headers:
        results.append({"name": "Strict-Transport-Security (HSTS)", "status": "Failed", "details": "HSTS header not found. Enforces HTTPS usage."})
    else:
        results.append({"name": "Strict-Transport-Security (HSTS)", "status": "Passed", "details": "HSTS header is present."})
        
    # Check for X-Content-Type-Options
    if headers.get('X-Content-Type-Options', '').lower() != 'nosniff':
        results.append({"name": "X-Content-Type-Options", "status": "Failed", "details": "Header not set to 'nosniff'. Browser may incorrectly interpret content types."})
    else:
        results.append({"name": "X-Content-Type-Options", "status": "Passed", "details": "Header is correctly set to 'nosniff'."})

    return results

def check_exposed_server_version(headers: dict):
    """A05:2021 - Security Misconfiguration"""
    server_header = headers.get('Server', '')
    if server_header and any(char.isdigit() for char in server_header):
        return {"name": "Server Version Disclosure", "status": "Failed", "details": f"Potentially verbose Server header found: '{server_header}'. This can reveal vulnerable software versions."}
    return {"name": "Server Version Disclosure", "status": "Passed", "details": "Server version information appears to be hidden."}

def check_forms_for_autocomplete(soup: BeautifulSoup):
    """A07:2021 - Identification and Authentication Failures"""
    password_inputs = soup.find_all('input', attrs={'type': 'password'})
    if not password_inputs:
        return {"name": "Password Field Autocomplete", "status": "Not Applicable", "details": "No password fields found on the page."}
    
    vulnerable_forms = [p for p in password_inputs if p.get('autocomplete', '').lower() != 'off' and p.get('autocomplete', '').lower() != 'new-password']
    if vulnerable_forms:
        return {"name": "Password Field Autocomplete", "status": "Failed", "details": "Found password fields that do not disable autocomplete, which can be a security risk on shared computers."}
    
    return {"name": "Password Field Autocomplete", "status": "Passed", "details": "Password fields correctly use autocomplete='off' or 'new-password'."}

def check_for_vulnerable_components_indicator(soup: BeautifulSoup):
    """A06:2021 - Vulnerable and Outdated Components"""
    generator_tag = soup.find('meta', attrs={'name': 'generator'})
    if generator_tag and generator_tag.get('content'):
        return {"name": "Software Version Disclosure (Meta)", "status": "Failed", "details": f"A 'generator' meta tag was found, potentially exposing software and version: {generator_tag.get('content')}"}
    return {"name": "Software Version Disclosure (Meta)", "status": "Passed", "details": "No 'generator' meta tag found."}

def check_sri_integrity(soup: BeautifulSoup):
    """A08:2021 - Software and Data Integrity Failures"""
    scripts = soup.find_all('script', src=True)
    styles = soup.find_all('link', rel='stylesheet', href=True)
    external_resources = scripts + styles
    
    if not external_resources:
        return {"name": "Subresource Integrity (SRI)", "status": "Not Applicable", "details": "No external scripts or stylesheets found to check."}

    missing_sri = [
        tag.get('src') or tag.get('href') 
        for tag in external_resources 
        if not tag.get('integrity') and ('http' in (tag.get('src') or tag.get('href')))
    ]

    if missing_sri:
        return {"name": "Subresource Integrity (SRI)", "status": "Failed", "details": f"Found {len(missing_sri)} external resource(s) without an integrity attribute. This could allow malicious code execution if the CDN is compromised."}
    
    return {"name": "Subresource Integrity (SRI)", "status": "Passed", "details": "All external resources appear to use Subresource Integrity."}

def run_all_checks(response: requests.Response, soup: BeautifulSoup):
    """Runs all passive checks and aggregates results."""
    headers = response.headers
    
    owasp_map = {
        "A01:2021 - Broken Access Control": [{"name": "Passive Check Limitation", "status": "Info", "details": "Cannot be reliably detected with passive, external scans. Requires authenticated testing."}],
        "A02:2021 - Cryptographic Failures": [{"name": "HTTPS Enforcement (HSTS)", "status": "Passed" if 'Strict-Transport-Security' in headers else "Failed", "details": "HSTS header presence indicates strong HTTPS enforcement."}],
        "A03:2021 - Injection": [{"name": "Defense via CSP", "status": "Passed" if 'Content-Security-Policy' in headers else "Failed", "details": "A strong Content-Security-Policy is a primary defense against injection attacks like XSS."}],
        "A04:2021 - Insecure Design": [{"name": "MIME-Type Sniffing Protection", "status": "Passed" if headers.get('X-Content-Type-Options', '').lower() == 'nosniff' else "Failed", "details": "X-Content-Type-Options: nosniff prevents browsers from misinterpreting content types."}],
        "A05:2021 - Security Misconfiguration": check_security_headers(headers) + [check_exposed_server_version(headers)],
        "A06:2021 - Vulnerable Components": [check_for_vulnerable_components_indicator(soup)],
        "A07:2021 - Identification & Auth Failures": [check_forms_for_autocomplete(soup)],
        "A08:2021 - Software & Data Integrity": [check_sri_integrity(soup)],
        "A09:2021 - Security Logging & Monitoring": [{"name": "Passive Check Limitation", "status": "Info", "details": "Cannot be detected externally. Requires access to server logs and infrastructure."}],
        "A10:2021 - Server-Side Request Forgery": [{"name": "Passive Check Limitation", "status": "Info", "details": "Cannot be detected with passive, external scans. Requires targeted, active testing."}],
    }
    return owasp_map