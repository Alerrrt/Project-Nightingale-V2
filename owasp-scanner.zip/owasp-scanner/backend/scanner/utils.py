import socket
import ipaddress
from urllib.parse import urlparse

# List of private/reserved IP ranges
RESERVED_RANGES = [
    "0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8",
    "169.254.0.0/16", "172.16.0.0/12", "192.0.0.0/24", "192.0.2.0/24",
    "192.88.99.0/24", "192.168.0.0/16", "198.18.0.0/15", "198.51.100.0/24",
    "203.0.113.0/24", "224.0.0.0/4", "240.0.0.0/4", "255.255.255.255/32",
    "::1/128", "fc00::/7", "fe80::/10"
]

def validate_and_resolve_url(url: str) -> str:
    """
    Validates that a URL uses HTTPS and resolves to a public IP address.
    Raises ValueError on failure.
    Returns the resolved IP address.
    """
    if not isinstance(url, str) or not url.strip():
        raise ValueError("URL cannot be empty.")

    try:
        parsed_url = urlparse(url)
        if parsed_url.scheme != 'https':
            raise ValueError("URL must use HTTPS.")
        
        hostname = parsed_url.hostname
        if not hostname:
            raise ValueError("Invalid URL structure.")

    except Exception:
        raise ValueError("Invalid URL format.")

    try:
        ip_address_str = socket.gethostbyname(hostname)
        ip = ipaddress.ip_address(ip_address_str)

        if ip.is_private or ip.is_loopback or ip.is_reserved:
             raise ValueError(f"URL resolves to a private or reserved IP address: {ip_address_str}")

        for reserved_range in RESERVED_RANGES:
            if ip in ipaddress.ip_network(reserved_range):
                raise ValueError(f"URL resolves to a reserved IP range: {ip_address_str}")

        return ip_address_str

    except socket.gaierror:
        raise ValueError(f"Could not resolve hostname: {hostname}")
    except Exception as e:
        raise ValueError(f"An unexpected error occurred during URL validation: {e}")