from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
from bs4 import BeautifulSoup

from scanner.utils import validate_and_resolve_url
from scanner.checks import run_all_checks

app = Flask(__name__)
# Enable CORS for requests from the frontend's origin
CORS(app, resources={r"/scan": {"origins": "http://localhost:8080"}})

@app.route('/scan', methods=['POST'])
def scan_url():
    data = request.get_json()
    if not data or 'url' not in data:
        return jsonify({"error": "URL is required."}), 400

    url = data['url']

    try:
        # 1. Validate URL (HTTPS, public IP)
        resolved_ip = validate_and_resolve_url(url)

        # 2. Perform the scan
        headers = {
            'User-Agent': 'OWASP-Passive-Scanner/1.0 (+http://localhost:8080)'
        }
        response = requests.get(url, headers=headers, timeout=10, verify=True)
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)

        soup = BeautifulSoup(response.text, 'html.parser')

        # 3. Extract basic info
        title_tag = soup.find('title')
        title = title_tag.string.strip() if title_tag else "No title found"
        
        meta_desc_tag = soup.find('meta', attrs={'name': 'description'})
        meta_description = meta_desc_tag['content'].strip() if meta_desc_tag and meta_desc_tag.get('content') else "No meta description found"

        # 4. Run all checks
        scan_results = run_all_checks(response, soup)

        # 5. Assemble the final JSON response
        results = {
            "basic_info": {
                "url": url,
                "resolved_ip": resolved_ip,
                "title": title,
                "meta_description": meta_description,
                "server": response.headers.get('Server', 'Not specified'),
            },
            "owasp_top_10_checks": scan_results
        }
        return jsonify(results)

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Network error or invalid response: {e}"}), 500
    except Exception as e:
        app.logger.error(f"An unexpected error occurred: {e}")
        return jsonify({"error": "An unexpected server error occurred."}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)