import pytest
import json
from app import app

@pytest.fixture
def client():
    with app.test_client() as client:
        yield client

def test_scan_endpoint_invalid_url(client):
    """Test scan with an invalid URL (non-HTTPS)."""
    response = client.post('/scan', json={'url': 'http://example.com'})
    assert response.status_code == 400
    data = json.loads(response.data)
    assert 'URL must use HTTPS' in data['error']

def test_scan_endpoint_private_ip(client, mocker):
    """Test scan with a URL resolving to a private IP."""
    mocker.patch('scanner.utils.socket.gethostbyname', return_value='192.168.1.1')
    response = client.post('/scan', json={'url': 'https://internal.service'})
    assert response.status_code == 400
    data = json.loads(response.data)
    assert 'private or reserved IP' in data['error']

def test_scan_endpoint_success(client, mocker):
    """Test a successful scan, mocking external requests."""
    # Mock socket resolution
    mocker.patch('scanner.utils.socket.gethostbyname', return_value='93.184.216.34')
    
    # Mock requests.get
    mock_response = mocker.Mock()
    mock_response.status_code = 200
    mock_response.headers = {
        'Content-Type': 'text/html',
        'Server': 'ECS (dcb/7F84)',
        'Content-Security-Policy': "default-src 'self'"
    }
    mock_response.text = '<html><head><title>Example Domain</title></head><body><p>Hello</p></body></html>'
    mocker.patch('requests.get', return_value=mock_response)

    response = client.post('/scan', json={'url': 'https://example.com'})
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['basic_info']['title'] == 'Example Domain'
    assert 'owasp_top_10_checks' in data
    assert 'A05:2021 - Security Misconfiguration' in data['owasp_top_10_checks']