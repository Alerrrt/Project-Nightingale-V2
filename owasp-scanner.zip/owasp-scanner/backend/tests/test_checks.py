import pytest
from bs4 import BeautifulSoup
from unittest.mock import MagicMock

from scanner.checks import (
    check_security_headers,
    check_exposed_server_version,
    check_forms_for_autocomplete,
    check_sri_integrity
)

def test_check_security_headers_all_missing():
    headers = {}
    results = check_security_headers(headers)
    assert len(results) == 4
    assert all(r['status'] == 'Failed' for r in results)

def test_check_security_headers_all_present():
    headers = {
        'Content-Security-Policy': "default-src 'self'",
        'X-Frame-Options': 'DENY',
        'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
        'X-Content-Type-Options': 'nosniff'
    }
    results = check_security_headers(headers)
    assert all(r['status'] == 'Passed' for r in results)

def test_check_exposed_server_version():
    headers_exposed = {'Server': 'Apache/2.4.1 (Unix)'}
    result = check_exposed_server_version(headers_exposed)
    assert result['status'] == 'Failed'
    
    headers_hidden = {'Server': 'nginx'}
    result = check_exposed_server_version(headers_hidden)
    assert result['status'] == 'Passed'

def test_check_forms_for_autocomplete():
    html_vulnerable = '<form><input type="password"></form>'
    soup = BeautifulSoup(html_vulnerable, 'html.parser')
    result = check_forms_for_autocomplete(soup)
    assert result['status'] == 'Failed'

    html_secure = '<form><input type="password" autocomplete="new-password"></form>'
    soup = BeautifulSoup(html_secure, 'html.parser')
    result = check_forms_for_autocomplete(soup)
    assert result['status'] == 'Passed'

def test_check_sri_integrity():
    html_missing_sri = '<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>'
    soup = BeautifulSoup(html_missing_sri, 'html.parser')
    result = check_sri_integrity(soup)
    assert result['status'] == 'Failed'

    html_with_sri = '<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>'
    soup = BeautifulSoup(html_with_sri, 'html.parser')
    result = check_sri_integrity(soup)
    assert result['status'] == 'Passed'